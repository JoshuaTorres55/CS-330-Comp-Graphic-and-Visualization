///////////////////////////////////////////////////////////////////////////////
// maincode.cpp
// ============
// Entry point for OpenGL application - initializes GLEW, GLFW
//
// AUTHOR: Joshua Torres
// Created for CS-330 OpenGL Project
///////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <cstdlib>
#include <GL/glew.h>
#include "GLFW/glfw3.h"

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "SceneManager.h"
#include "ViewManager.h"
#include "ShaderManager.h"

// Global variables
namespace {
    const char* const WINDOW_TITLE = "OpenGL Project";
    GLFWwindow* g_Window = nullptr;

    SceneManager* g_SceneManager = nullptr;
    ShaderManager* g_ShaderManager = nullptr;
    ViewManager* g_ViewManager = nullptr;
}

bool InitializeGLFW();
bool InitializeGLEW();

int main(int argc, char* argv[])
{
    if (!InitializeGLFW()) return EXIT_FAILURE;

    g_ShaderManager = new ShaderManager();
    g_ViewManager = new ViewManager(g_ShaderManager);
    g_Window = g_ViewManager->CreateDisplayWindow(WINDOW_TITLE);

    if (!InitializeGLEW()) return EXIT_FAILURE;

    g_ShaderManager->LoadShaders("shaders/vertexShader.glsl",
        "shaders/fragmentShader.glsl");
    g_ShaderManager->use();

    g_SceneManager = new SceneManager(g_ShaderManager);
    g_SceneManager->PrepareScene();

    while (!glfwWindowShouldClose(g_Window))
    {
        glEnable(GL_DEPTH_TEST);
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        g_ViewManager->PrepareSceneView();
        g_SceneManager->RenderScene();

        glfwSwapBuffers(g_Window);
        glfwPollEvents();
    }

    delete g_SceneManager;
    delete g_ViewManager;
    delete g_ShaderManager;

    exit(EXIT_SUCCESS);
}

bool InitializeGLFW()
{
    if (!glfwInit()) return false;

#ifdef __APPLE__
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#else
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#endif

    return true;
}

bool InitializeGLEW()
{
    GLenum err = glewInit();
    if (GLEW_OK != err)
    {
        std::cerr << glewGetErrorString(err) << std::endl;
        return false;
    }

    std::cout << "INFO: OpenGL Successfully Initialized\n";
    std::cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << "\n";
    return true;
}
