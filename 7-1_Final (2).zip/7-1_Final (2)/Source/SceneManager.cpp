///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"
#include <glm/gtx/transform.hpp>
#include <iostream>

SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();
}

SceneManager::~SceneManager()
{
    delete m_basicMeshes;
    m_pShaderManager = nullptr;
}

void SceneManager::PrepareScene()
{
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadSphereMesh();
    m_basicMeshes->LoadPlaneMesh();
}

void SceneManager::RenderScene()
{
    glm::vec3 scale(1.0f);
    glm::vec3 pos(0.0f);

    // Example: Draw a plane
    SetTransformations(glm::vec3(10.0f, 1.0f, 10.0f), 0, 0, 0, glm::vec3(0, 0, 0));
    m_basicMeshes->DrawPlaneMesh();

    // Example: Draw a cube
    SetTransformations(glm::vec3(1.0f), 0, 45, 0, glm::vec3(0, 1, 0));
    SetShaderColor(1.0f, 0.0f, 0.0f, 1.0f);
    m_basicMeshes->DrawBoxMesh();
}

void SceneManager::SetTransformations(glm::vec3 scale, float rotX, float rotY, float rotZ, glm::vec3 pos)
{
    glm::mat4 model = glm::translate(pos) *
        glm::rotate(glm::radians(rotX), glm::vec3(1, 0, 0)) *
        glm::rotate(glm::radians(rotY), glm::vec3(0, 1, 0)) *
        glm::rotate(glm::radians(rotZ), glm::vec3(0, 0, 1)) *
        glm::scale(scale);
    m_pShaderManager->setMat4Value("model", model);
}

void SceneManager::SetShaderColor(float r, float g, float b, float a)
{
    m_pShaderManager->setVec4Value("objectColor", glm::vec4(r, g, b, a));
}
