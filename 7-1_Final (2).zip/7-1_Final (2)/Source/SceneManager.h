#pragma once
#include "ShaderManager.h"
#include "ShapeMeshes.h"
#include <glm/glm.hpp>
#include <string>
#include <functional>

class SceneManager
{
public:
    SceneManager(ShaderManager* pShaderManager);
    ~SceneManager();

    void PrepareScene();
    void RenderScene();

private:
    ShaderManager* m_pShaderManager;
    ShapeMeshes* m_basicMeshes;

    void SetTransformations(glm::vec3 scale, float rotX, float rotY, float rotZ, glm::vec3 pos);
    void SetShaderColor(float r, float g, float b, float a);
};
