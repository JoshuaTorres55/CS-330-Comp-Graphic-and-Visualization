///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"
#include <glm/gtc/matrix_transform.hpp>
#include <iostream>

ViewManager* ViewManager::s_Instance = nullptr;

ViewManager::ViewManager(ShaderManager* pShaderManager)
{
    s_Instance = this;
    m_pShaderManager = pShaderManager;
    m_pCamera = new Camera();
    m_pCamera->Position = glm::vec3(0, 5, 12);
    m_pCamera->Zoom = 80.0f;
    m_cameraSpeed = 2.5f;
    m_bOrthographicProjection = false;
}

ViewManager::~ViewManager()
{
    delete m_pCamera;
}

GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
    GLFWwindow* window = glfwCreateWindow(1000, 800, windowTitle, nullptr, nullptr);
    if (!window) { glfwTerminate(); return nullptr; }
    glfwMakeContextCurrent(window);
    m_pWindow = window;
    return window;
}

void ViewManager::PrepareSceneView()
{
    ProcessKeyboardEvents();
    glm::mat4 view = m_pCamera->GetViewMatrix();
    m_pShaderManager->setMat4Value("view", view);
    UpdateProjection();
}

void ViewManager::ProcessKeyboardEvents() {}
void ViewManager::UpdateProjection() {}
void ViewManager::Mouse_Position_Callback(GLFWwindow*, double, double) {}
void ViewManager::Mouse_Scroll_Callback(GLFWwindow*, double, double) {}
void ViewManager::Key_Callback(GLFWwindow*, int, int, int, int) {}
